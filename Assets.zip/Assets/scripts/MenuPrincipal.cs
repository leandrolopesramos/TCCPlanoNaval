﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MenuPrincipal : MonoBehaviour {

    public GameObject y;

    public void Botoes(int x)
    {

        if (x == 1)
        {
            SceneManager.LoadScene(1); //Menu Fases
        }
        if (x == 2)
        {
            y.SetActive(true); //Sobre Painel
        }
        if (x == 3)
        {
            y.SetActive(false);
        }
    }
}
