﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Niveis : MonoBehaviour
{

    public void Botoes(int x)
    {
        if (x == 0)
        {
            SceneManager.LoadScene(0); //Voltar Menu
        }
        else
        {
            SceneManager.LoadScene(2); //Avançar Fase
        }
    }
}
